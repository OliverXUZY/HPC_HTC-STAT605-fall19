#!/bin/bash

sort -m sortedWord.*  | uniq -c > countsOfWords
