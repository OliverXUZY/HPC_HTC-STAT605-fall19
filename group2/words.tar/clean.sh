#!/bin/bash

# Before running this script, change "rm" to "ls" and run that
# version. Check its output to be sure you are not including files you
# should not remove.

rm *.err *.out *.log *.0[0-4] words.dag.condor.sub countsOfWords words.dag.metrics all *rescue*
